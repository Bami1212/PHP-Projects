
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Add File</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div id="container">
    <div id = "header">
    <h1>Geez Movie Center</h1>
    </div>

    <div id="subcont">
    
    <div id="nav">
        <h1>Navigation</h1>
            <ul>
                    <li><a href="file_add/insertmovies.php">Add Movies</a></li>
                    <li><a href="file_add/insertseries.php">Add Series</a></li>
                    <li><a href="file_add/insertgame.php">Add Game</a></li>
                    <li><a href="file_add/insertamharic.php">Add Amharic</a></li>
                    <li><a href="index.php">Back</a></li>
            </ul>
    </div>

    <div id="content">
<div class="form">
<p>Add Files Here.</p>
</div>
    </div>
<div id="footer">
            2020 Geez Movie center
</div>
</div>
</body>
</html>